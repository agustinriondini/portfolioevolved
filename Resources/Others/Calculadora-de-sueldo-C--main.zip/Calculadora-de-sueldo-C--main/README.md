# Calculadora-de-sueldo-C-

Calculadora de sueldos c++ por consola:

Proyecto para utilizar c++..

DESARROLLO:

    Version incial proyecto de laboratorio Universidad. Trabajar funciones logicas de C++
